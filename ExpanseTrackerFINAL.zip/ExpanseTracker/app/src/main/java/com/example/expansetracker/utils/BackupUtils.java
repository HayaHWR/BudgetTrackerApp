
package com.example.expansetracker.utils;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import com.example.expansetracker.database.AppDatabase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BackupUtils {
    private static final String TAG = "BackupUtils";

    // Erstellt ein Backup der Datenbank in den Download-Ordner
    public static boolean exportDatabase(Context context) {
        try {
            File backupDir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), "ExpanseTrackerBackups");

            if (!backupDir.exists()) {
                boolean dirCreated = backupDir.mkdirs();
                if (!dirCreated) {
                    Log.e(TAG, "Konnte Backup-Verzeichnis nicht erstellen");
                    return false;
                }
            }

            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            String backupFileName = "expanse_tracker_backup_" + timeStamp + ".db";
            File currentDB = context.getDatabasePath(AppDatabase.DATABASE_NAME);
            File backupDB = new File(backupDir, backupFileName);

            if (currentDB.exists()) {
                FileChannel src = new FileInputStream(currentDB).getChannel();
                FileChannel dst = new FileOutputStream(backupDB).getChannel();
                dst.transferFrom(src, 0, src.size());
                src.close();
                dst.close();
                Log.i(TAG, "Backup erstellt: " + backupDB.getAbsolutePath());
                return true;
            }

            return false;
        } catch (IOException e) {
            Log.e(TAG, "Backup-Fehler: ", e);
            return false;
        }
    }

    // Stellt die Datenbank aus einer Backup-Datei wieder her
    public static boolean importDatabase(Context context, File backupFile) {
        try {
            // Stellen Sie sicher, dass die App geschlossen wird, um die Datenbank zu schließen
            File currentDB = context.getDatabasePath(AppDatabase.DATABASE_NAME);

            if (backupFile.exists()) {
                FileChannel src = new FileInputStream(backupFile).getChannel();
                FileChannel dst = new FileOutputStream(currentDB).getChannel();
                dst.transferFrom(src, 0, src.size());
                src.close();
                dst.close();
                Log.i(TAG, "Datenbank wiederhergestellt von: " + backupFile.getAbsolutePath());
                return true;
            }

            return false;
        } catch (IOException e) {
            Log.e(TAG, "Wiederherstellungs-Fehler: ", e);
            return false;
        }
    }

    // Gibt eine Liste aller verfügbaren Backups zurück
    public static File[] getAvailableBackups() {
        File backupDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS), "ExpanseTrackerBackups");

        if (!backupDir.exists()) {
            return new File[0];
        }

        return backupDir.listFiles((dir, name) -> name.endsWith(".db"));
    }

    // Löscht ein Backup
    public static boolean deleteBackup(File backupFile) {
        if (backupFile.exists()) {
            return backupFile.delete();
        }
        return false;
    }
}
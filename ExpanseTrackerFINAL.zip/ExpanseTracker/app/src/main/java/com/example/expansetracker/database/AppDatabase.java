package com.example.expansetracker.database;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.expansetracker.database.dao.CategoryDao;
import com.example.expansetracker.database.dao.TransactionDao;
import com.example.expansetracker.database.dao.UserDao;
import com.example.expansetracker.database.entity.Category;
import com.example.expansetracker.database.entity.Transaction;
import com.example.expansetracker.database.entity.User;
import com.example.expansetracker.utils.DateConverter;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {User.class, Category.class, Transaction.class}, version = 1, exportSchema = false)
@TypeConverters({DateConverter.class})
public abstract class AppDatabase extends RoomDatabase {

    public static final String DATABASE_NAME = "expanse_tracker_database";

    public abstract UserDao userDao();
    public abstract CategoryDao categoryDao();
    public abstract TransactionDao transactionDao();

    private static volatile AppDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, DATABASE_NAME)
                            .addCallback(sRoomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);

            databaseWriteExecutor.execute(() -> {
                // Populate the database in the background when it's first created
                CategoryDao categoryDao = INSTANCE.categoryDao();
                UserDao userDao = INSTANCE.userDao();

                // Insert a default user
                User defaultUser = new User("user@example.com", "password", "Default User", "EUR", "en");
                long userId = userDao.insert(defaultUser);

                // Insert default categories
                // Income categories
                categoryDao.insert(new Category("Salary", "INCOME", "ic_salary", "#4CAF50", userId));
                categoryDao.insert(new Category("Family", "INCOME", "ic_family", "#2196F3", userId));

                // Expense categories
                categoryDao.insert(new Category("Food", "EXPENSE", "ic_food", "#F44336", userId));
                categoryDao.insert(new Category("Transport", "EXPENSE", "ic_transport", "#FF9800", userId));
                categoryDao.insert(new Category("Bank", "EXPENSE", "ic_bank", "#9C27B0", userId));
            });
        }
    };
}
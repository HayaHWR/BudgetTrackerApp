package com.example.expansetracker.models;

public class TransactionModel {
    private long id;
    private double amount;
    private String description;
    private String categoryName;
    private String categoryIcon;
    private String transactionDate;
    private String transactionType; // "INCOME" or "EXPENSE"
    private String note;

    public TransactionModel() {
    }

    public TransactionModel(long id, double amount, String description, String categoryName,
                            String categoryIcon, String transactionDate, String transactionType, String note) {
        this.id = id;
        this.amount = amount;
        this.description = description;
        this.categoryName = categoryName;
        this.categoryIcon = categoryIcon;
        this.transactionDate = transactionDate;
        this.transactionType = transactionType;
        this.note = note;
    }

    // Getters and Setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryIcon() {
        return categoryIcon;
    }

    public void setCategoryIcon(String categoryIcon) {
        this.categoryIcon = categoryIcon;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
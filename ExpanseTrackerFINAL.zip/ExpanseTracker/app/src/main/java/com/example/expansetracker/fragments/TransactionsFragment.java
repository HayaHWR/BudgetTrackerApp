package com.example.expansetracker.fragments;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.expansetracker.R;
import com.example.expansetracker.adapters.TransactionAdapter;
import com.example.expansetracker.database.AppDatabase;
import com.example.expansetracker.database.entity.Transaction;
import com.example.expansetracker.models.TransactionModel;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TransactionsFragment extends Fragment implements TransactionAdapter.TransactionAdapterListener {

    private TextView tvMonthYear;
    private TextView tvIncomeValue;
    private TextView tvExpensesValue;
    private RecyclerView rvAllTransactions;
    private TransactionAdapter transactionAdapter;

    private List<TransactionModel> transactionList = new ArrayList<>();

    private static final int PERMISSION_REQUEST_CODE = 123;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_transactions, container, false);

        // Initialize views
        tvMonthYear = view.findViewById(R.id.tv_month_year);
        tvIncomeValue = view.findViewById(R.id.tv_income_value);
        tvExpensesValue = view.findViewById(R.id.tv_expenses_value);
        rvAllTransactions = view.findViewById(R.id.rv_all_transactions);

        // Removed FAB reference and click listener

        // Setup RecyclerView
        rvAllTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        loadDummyData();
        transactionAdapter = new TransactionAdapter(requireContext(), transactionList);
        transactionAdapter.setListener(this);
        rvAllTransactions.setAdapter(transactionAdapter);

        // Set initial data
        tvMonthYear.setText("Mar 2025");
        updateBalanceInfo();

        return view;
    }

    private void navigateToAddTransaction() {
        Fragment fragment = new AddTransactionFragment();
        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    // Rest of the code remains unchanged...

    private boolean checkStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int result = requireContext().checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            return result == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(requireContext(), "Permission granted, you can now export", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(requireContext(), "Storage permission is required for export", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void loadDummyData() {
        // Demo data
        TransactionModel transaction1 = new TransactionModel();
        transaction1.setId(1);
        transaction1.setAmount(7000.0);
        transaction1.setDescription("Monthly Salary");
        transaction1.setCategoryName("Salary");
        transaction1.setCategoryIcon("ic_launcher");
        transaction1.setTransactionDate("22 Dec 2023");
        transaction1.setTransactionType("INCOME");

        TransactionModel transaction2 = new TransactionModel();
        transaction2.setId(2);
        transaction2.setAmount(8000.0);
        transaction2.setDescription("Family Support");
        transaction2.setCategoryName("Family");
        transaction2.setCategoryIcon("ic_launcher");
        transaction2.setTransactionDate("17 Jan 2024");
        transaction2.setTransactionType("INCOME");

        TransactionModel transaction3 = new TransactionModel();
        transaction3.setId(3);
        transaction3.setAmount(6000.0);
        transaction3.setDescription("Bank Transfer");
        transaction3.setCategoryName("Bank");
        transaction3.setCategoryIcon("ic_launcher");
        transaction3.setTransactionDate("16 June 2024");
        transaction3.setTransactionType("EXPENSE");

        transactionList.add(transaction1);
        transactionList.add(transaction2);
        transactionList.add(transaction3);
    }

    // Implementation of the TransactionAdapterListener interface
    @Override
    public void onTransactionClick(TransactionModel transaction) {
        // Show transaction details
        Toast.makeText(requireContext(), "Transaction details: " + transaction.getCategoryName(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onEditClick(TransactionModel transaction) {
        // Delegate to the existing method
        onEditTransaction(transaction);
    }

    @Override
    public void onDeleteClick(TransactionModel transaction) {
        // Delegate to the existing method
        onDeleteTransaction(transaction);
    }

    @Override
    public void onEditTransaction(TransactionModel transaction) {
        // Open AddTransactionFragment in edit mode
        AddTransactionFragment editFragment = new AddTransactionFragment();

        // Pass transaction data to fragment
        Bundle args = new Bundle();
        args.putLong("transaction_id", transaction.getId());
        args.putDouble("amount", transaction.getAmount());
        args.putString("date", transaction.getTransactionDate());
        args.putString("category", transaction.getCategoryName());
        args.putString("note", transaction.getDescription());
        args.putString("type", transaction.getTransactionType());
        args.putBoolean("edit_mode", true);
        editFragment.setArguments(args);

        // Fragment transaction
        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, editFragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onDeleteTransaction(final TransactionModel transaction) {
        // Show confirmation dialog
        new AlertDialog.Builder(requireContext())
                .setTitle("Delete Transaction")
                .setMessage("Are you sure you want to delete this transaction?")
                .setPositiveButton("Delete", (dialog, which) -> deleteTransaction(transaction))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteTransaction(final TransactionModel transaction) {
        // Delete in background
        AppDatabase db = AppDatabase.getDatabase(requireContext());

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                // Get the transaction using the direct method that returns a Transaction object
                Transaction dbTransaction = db.transactionDao().getTransactionByIdDirect(transaction.getId());

                // Delete from database if found
                if (dbTransaction != null) {
                    db.transactionDao().delete(dbTransaction);
                }

                // Update UI on main thread
                requireActivity().runOnUiThread(() -> {
                    // Remove from list and update adapter
                    transactionList.remove(transaction);
                    transactionAdapter.notifyDataSetChanged();
                    Toast.makeText(requireContext(), "Transaction deleted", Toast.LENGTH_SHORT).show();

                    // Update summary and notify listeners
                    updateBalanceInfo();
                    onTransactionDeleted();
                });
            } catch (Exception e) {
                e.printStackTrace();
                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(requireContext(), "Error deleting transaction: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
            }
        });
    }
    @Override
    public void onTransactionDeleted() {
        // Update the balance display
        updateBalanceInfo();
    }

    @Override
    public void onTransactionEdited() {
        // Called when a transaction is edited
        updateBalanceInfo();
    }

    private void updateBalanceInfo() {
        // Update the income and expense display
        double totalIncome = 0;
        double totalExpense = 0;

        for (TransactionModel transaction : transactionList) {
            if (transaction.getTransactionType().equals("INCOME")) {
                totalIncome += transaction.getAmount();
            } else {
                totalExpense += transaction.getAmount();
            }
        }

        tvIncomeValue.setText(String.valueOf(totalIncome));
        tvExpensesValue.setText(String.valueOf(totalExpense));
    }

    // Alias for updateBalanceInfo for backward compatibility
    private void updateSummary() {
        updateBalanceInfo();
    }
}
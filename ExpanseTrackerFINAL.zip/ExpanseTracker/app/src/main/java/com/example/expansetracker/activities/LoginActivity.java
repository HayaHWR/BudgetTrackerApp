package com.example.expansetracker.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.expansetracker.MainActivity;
import com.example.expansetracker.R;
import com.example.expansetracker.database.AppDatabase;
import com.example.expansetracker.database.dao.UserDao;
import com.example.expansetracker.database.entity.User;
import com.example.expansetracker.utils.Constants;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LoginActivity extends AppCompatActivity {

    private TextInputLayout tilEmail;
    private TextInputEditText etEmail;
    private TextInputLayout tilPassword;
    private TextInputEditText etPassword;
    private Button btnLogin;
    private TextView tvForgotPassword;
    private TextView tvRegister;

    private AppDatabase db;
    private ExecutorService executorService;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize database and executor
        db = AppDatabase.getDatabase(this);
        executorService = Executors.newSingleThreadExecutor();

        // Initialize shared preferences
        sharedPreferences = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE);

        // Check if user is already logged in
        if (sharedPreferences.getBoolean(Constants.KEY_IS_LOGGED_IN, false)) {
            navigateToMainActivity();
            return;
        }

        // Initialize views
        tilEmail = findViewById(R.id.til_email);
        etEmail = findViewById(R.id.et_email);
        tilPassword = findViewById(R.id.til_password);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        tvForgotPassword = findViewById(R.id.tv_forgot_password);
        tvRegister = findViewById(R.id.tv_register);

        // Setup login button
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    login();
                }
            }
        });

        // Setup forgot password text
        tvForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
                startActivity(intent);
            }
        });

        // Setup register text
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean validateInputs() {
        boolean isValid = true;

        // Validate email
        String email = etEmail.getText().toString().trim();
        if (email.isEmpty()) {
            tilEmail.setError("Please enter email");
            isValid = false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tilEmail.setError("Please enter a valid email");
            isValid = false;
        } else {
            tilEmail.setError(null);
        }

        // Validate password
        String password = etPassword.getText().toString().trim();
        if (password.isEmpty()) {
            tilPassword.setError("Please enter password");
            isValid = false;
        } else {
            tilPassword.setError(null);
        }

        return isValid;
    }

    private void login() {
        final String email = etEmail.getText().toString().trim();
        final String password = etPassword.getText().toString().trim();

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                UserDao userDao = db.userDao();
                final User user = userDao.login(email, password);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (user != null) {
                            // Save login status and user info
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putBoolean(Constants.KEY_IS_LOGGED_IN, true);
                            editor.putLong(Constants.KEY_USER_ID, user.getId());
                            editor.putString(Constants.KEY_USER_EMAIL, user.getEmail());
                            editor.putString(Constants.KEY_USER_NAME, user.getName());
                            editor.putString(Constants.KEY_CURRENCY_CODE, user.getCurrencyCode());
                            editor.putString(Constants.KEY_LANGUAGE, user.getLanguage());
                            editor.apply();

                            // Navigate to main activity
                            navigateToMainActivity();
                        } else {
                            Toast.makeText(LoginActivity.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executorService != null) {
            executorService.shutdown();
        }
    }
}
package com.example.expansetracker.database.entity;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.TypeConverters;

import java.util.Date;

@Entity(tableName = "transactions")
public class Transaction {
    @PrimaryKey(autoGenerate = true)
    private long id;

    @ColumnInfo(name = "amount")
    private double amount;

    @ColumnInfo(name = "description")
    private String description;

    @ColumnInfo(name = "category_id")
    private long categoryId;

    @ColumnInfo(name = "transaction_date")
    private Date transactionDate;

    @ColumnInfo(name = "created_at")
    private Date createdAt;

    @ColumnInfo(name = "transaction_type")
    private String transactionType; // "INCOME" or "EXPENSE"

    @ColumnInfo(name = "user_id")
    private long userId;

    @ColumnInfo(name = "note")
    private String note;

    // Constructors
    public Transaction() {
    }
    @Ignore

    public Transaction(double amount, String description, long categoryId,
                       Date transactionDate, String transactionType, long userId, String note) {
        this.amount = amount;
        this.description = description;
        this.categoryId = categoryId;
        this.transactionDate = transactionDate;
        this.createdAt = new Date();
        this.transactionType = transactionType;
        this.userId = userId;
        this.note = note;
    }

    // Getters and Setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(long categoryId) {
        this.categoryId = categoryId;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
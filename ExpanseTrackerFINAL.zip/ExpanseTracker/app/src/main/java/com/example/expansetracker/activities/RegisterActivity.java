package com.example.expansetracker.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.expansetracker.R;
import com.example.expansetracker.database.AppDatabase;
import com.example.expansetracker.database.dao.UserDao;
import com.example.expansetracker.database.entity.User;
import com.example.expansetracker.utils.Constants;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RegisterActivity extends AppCompatActivity {

    private TextInputLayout tilName;
    private TextInputEditText etName;
    private TextInputLayout tilEmail;
    private TextInputEditText etEmail;
    private TextInputLayout tilPassword;
    private TextInputEditText etPassword;
    private TextInputLayout tilConfirmPassword;
    private TextInputEditText etConfirmPassword;
    private Button btnRegister;
    private TextView tvLogin;

    private AppDatabase db;
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize database and executor
        db = AppDatabase.getDatabase(this);
        executorService = Executors.newSingleThreadExecutor();

        // Initialize views
        tilName = findViewById(R.id.til_name);
        etName = findViewById(R.id.et_name);
        tilEmail = findViewById(R.id.til_email);
        etEmail = findViewById(R.id.et_email);
        tilPassword = findViewById(R.id.til_password);
        etPassword = findViewById(R.id.et_password);
        tilConfirmPassword = findViewById(R.id.til_confirm_password);
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        btnRegister = findViewById(R.id.btn_register);
        tvLogin = findViewById(R.id.tv_login);

        // Setup register button
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    register();
                }
            }
        });

        // Setup login text
        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back to login screen
            }
        });
    }

    private boolean validateInputs() {
        boolean isValid = true;

        // Validate name
        String name = etName.getText().toString().trim();
        if (name.isEmpty()) {
            tilName.setError("Please enter name");
            isValid = false;
        } else {
            tilName.setError(null);
        }

        // Validate email
        String email = etEmail.getText().toString().trim();
        if (email.isEmpty()) {
            tilEmail.setError("Please enter email");
            isValid = false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tilEmail.setError("Please enter a valid email");
            isValid = false;
        } else {
            tilEmail.setError(null);
        }

        // Validate password
        String password = etPassword.getText().toString().trim();
        if (password.isEmpty()) {
            tilPassword.setError("Please enter password");
            isValid = false;
        } else if (password.length() < 6) {
            tilPassword.setError("Password must be at least 6 characters");
            isValid = false;
        } else {
            tilPassword.setError(null);
        }

        // Validate confirm password
        String confirmPassword = etConfirmPassword.getText().toString().trim();
        if (confirmPassword.isEmpty()) {
            tilConfirmPassword.setError("Please confirm password");
            isValid = false;
        } else if (!confirmPassword.equals(password)) {
            tilConfirmPassword.setError("Passwords do not match");
            isValid = false;
        } else {
            tilConfirmPassword.setError(null);
        }

        return isValid;
    }

    private void register() {
        final String name = etName.getText().toString().trim();
        final String email = etEmail.getText().toString().trim();
        final String password = etPassword.getText().toString().trim();

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                UserDao userDao = db.userDao();

                // Check if email is already registered
                final User existingUser = userDao.getUserByEmail(email);

                if (existingUser != null) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tilEmail.setError("Email already registered");
                        }
                    });
                    return;
                }

                // Create new user
                User newUser = new User(email, password, name, "EUR", "en");
                final long userId = userDao.insert(newUser);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (userId > 0) {
                            // Save user info to shared preferences
                            SharedPreferences sharedPreferences = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putBoolean(Constants.KEY_IS_LOGGED_IN, true);
                            editor.putLong(Constants.KEY_USER_ID, userId);
                            editor.putString(Constants.KEY_USER_EMAIL, email);
                            editor.putString(Constants.KEY_USER_NAME, name);
                            editor.putString(Constants.KEY_CURRENCY_CODE, "EUR");
                            editor.putString(Constants.KEY_LANGUAGE, "en");
                            editor.apply();

                            // Navigate to main activity
                            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executorService != null) {
            executorService.shutdown();
        }
    }
}
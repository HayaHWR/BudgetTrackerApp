package com.example.expansetracker.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.expansetracker.R;
import com.example.expansetracker.activities.LoginActivity;
import com.example.expansetracker.utils.Constants;


public class SettingsFragment extends Fragment implements View.OnClickListener {

    private TextView tvCurrency;
    private LinearLayout layoutCurrency;
    private LinearLayout layoutCategories;
    private LinearLayout layoutLanguage;
    private LinearLayout layoutBackup;
    private LinearLayout layoutRestore;
    private LinearLayout layoutLogout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        // Initialize views
        tvCurrency = view.findViewById(R.id.tv_currency);
        layoutCurrency = view.findViewById(R.id.layout_currency);
        layoutCategories = view.findViewById(R.id.layout_categories);
        layoutLanguage = view.findViewById(R.id.layout_language);
        layoutBackup = view.findViewById(R.id.layout_backup);
        layoutRestore = view.findViewById(R.id.layout_restore);
        layoutLogout = view.findViewById(R.id.layout_logout);

        // Set click listeners
        layoutCurrency.setOnClickListener(this);
        layoutCategories.setOnClickListener(this);
        layoutLanguage.setOnClickListener(this);
        layoutBackup.setOnClickListener(this);
        layoutRestore.setOnClickListener(this);
        layoutLogout.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if (id == R.id.layout_currency) {
            showCurrencySelectionDialog();
        } else if (id == R.id.layout_categories) {
            // Starte das CategoryManagementFragment
            Fragment fragment = new CategoryManagementFragment();
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack(null)  // Damit man mit Zurück-Button zurückkehren kann
                    .commit();
        } else if (id == R.id.layout_language) {
            showLanguageSelectionDialog();
        } else if (id == R.id.layout_backup) {
            Toast.makeText(getContext(), "Backup functionality will be implemented", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.layout_restore) {
            Toast.makeText(getContext(), "Restore functionality will be implemented", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.layout_logout) {
            showLogoutConfirmationDialog();
        }
    }

    private void showCurrencySelectionDialog() {
        final String[] currencies = {"USD ($)", "EUR (€)", "GBP (£)", "JPY (¥)"};

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Select Currency");
        builder.setSingleChoiceItems(currencies, 0, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                tvCurrency.setText(currencies[which]);
                dialog.dismiss();
            }
        });
        builder.show();
    }

    private void showLanguageSelectionDialog() {
        final String[] languages = {"English", "German", "French", "Spanish"};

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Select Language");
        builder.setSingleChoiceItems(languages, 0, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getContext(), languages[which] + " selected", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
        builder.show();
    }

    private void showLogoutConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to logout?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Speichern Sie den Logout-Status in SharedPreferences
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences(
                        Constants.PREF_NAME, getActivity().MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean(Constants.KEY_IS_LOGGED_IN, false);
                editor.apply();

                // Starte die LoginActivity
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                getActivity().finish();
            }
        });
        builder.setNegativeButton("No", null);
        builder.show();
    }
}
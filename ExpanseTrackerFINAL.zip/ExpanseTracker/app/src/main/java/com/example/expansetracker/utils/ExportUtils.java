package com.example.expansetracker.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.expansetracker.models.TransactionModel;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ExportUtils {

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    /**
     * Überprüft und fordert Berechtigungen an, falls erforderlich
     */
    public static boolean verifyStoragePermissions(Activity activity) {
        int permission = ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
            return false;
        }
        return true;
    }

    /**
     * Exportiert Transaktionen als PDF
     */
    public static boolean exportToPDF(Context context, List<TransactionModel> transactions, String title) {
        if (transactions == null || transactions.isEmpty()) {
            Toast.makeText(context, "Keine Daten zum Exportieren", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Verzeichnis erstellen, falls es nicht existiert
        File pdfDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOCUMENTS), "ExpanseTracker");
        if (!pdfDir.exists()) {
            pdfDir.mkdirs();
        }

        // Dateiname mit Timestamp
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String pdfName = "transactions_" + timeStamp + ".pdf";
        File pdfFile = new File(pdfDir, pdfName);

        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(pdfFile));
            document.open();

            // Titel
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
            Paragraph titleParagraph = new Paragraph(title, titleFont);
            titleParagraph.setAlignment(Element.ALIGN_CENTER);
            document.add(titleParagraph);
            document.add(new Paragraph(" ")); // Leerzeile

            // Tabelle erstellen
            PdfPTable table = new PdfPTable(5); // 5 Spalten
            table.setWidthPercentage(100);

            // Spaltenüberschriften
            Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
            PdfPCell cell;

            cell = new PdfPCell(new Phrase("Kategorie", headerFont));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase("Betrag", headerFont));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase("Datum", headerFont));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase("Typ", headerFont));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase("Notiz", headerFont));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);

            // Daten hinzufügen
            for (TransactionModel transaction : transactions) {
                table.addCell(transaction.getCategoryName());

                String amount = (transaction.getTransactionType().equals("INCOME") ? "+" : "-") +
                        String.format("%.2f", transaction.getAmount());
                table.addCell(amount);

                table.addCell(transaction.getTransactionDate());
                table.addCell(transaction.getTransactionType().equals("INCOME") ? "Einnahme" : "Ausgabe");
                table.addCell(transaction.getNote() != null ? transaction.getNote() : "");
            }

            document.add(table);
            document.close();

            Toast.makeText(context, "PDF erfolgreich exportiert nach: " + pdfFile.getPath(),
                    Toast.LENGTH_LONG).show();
            return true;

        } catch (DocumentException | IOException e) {
            e.printStackTrace();
            Toast.makeText(context, "Fehler beim Exportieren: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    /**
     * Exportiert Transaktionen als CSV
     */
    public static boolean exportToCSV(Context context, List<TransactionModel> transactions) {
        if (transactions == null || transactions.isEmpty()) {
            Toast.makeText(context, "Keine Daten zum Exportieren", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Verzeichnis erstellen, falls es nicht existiert
        File csvDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOCUMENTS), "ExpanseTracker");
        if (!csvDir.exists()) {
            csvDir.mkdirs();
        }

        // Dateiname mit Timestamp
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String csvName = "transactions_" + timeStamp + ".csv";
        File csvFile = new File(csvDir, csvName);

        try {
            FileWriter fileWriter = new FileWriter(csvFile);

            CSVPrinter csvPrinter = new CSVPrinter(fileWriter, CSVFormat.DEFAULT.withHeader(
                    "Kategorie", "Betrag", "Datum", "Typ", "Notiz"));

            for (TransactionModel transaction : transactions) {
                String amount = (transaction.getTransactionType().equals("INCOME") ? "+" : "-") +
                        String.format("%.2f", transaction.getAmount());

                csvPrinter.printRecord(
                        transaction.getCategoryName(),
                        amount,
                        transaction.getTransactionDate(),
                        transaction.getTransactionType().equals("INCOME") ? "Einnahme" : "Ausgabe",
                        transaction.getNote() != null ? transaction.getNote() : ""
                );
            }

            csvPrinter.flush();
            csvPrinter.close();

            Toast.makeText(context, "CSV erfolgreich exportiert nach: " + csvFile.getPath(),
                    Toast.LENGTH_LONG).show();
            return true;

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(context, "Fehler beim Exportieren: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }
}
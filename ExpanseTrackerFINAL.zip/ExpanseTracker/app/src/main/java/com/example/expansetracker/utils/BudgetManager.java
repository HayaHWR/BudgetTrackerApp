package com.example.expansetracker.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class BudgetManager {
    private static final String PREF_NAME = "budget_prefs";
    private static final String KEY_MONTHLY_BUDGET = "monthly_budget";

    private final SharedPreferences prefs;

    public BudgetManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void setMonthlyBudget(double amount) {
        prefs.edit().putFloat(KEY_MONTHLY_BUDGET, (float) amount).apply();
    }

    public double getMonthlyBudget() {
        return prefs.getFloat(KEY_MONTHLY_BUDGET, 0f);
    }

    public boolean isOverBudget(double currentExpenses) {
        double budget = getMonthlyBudget();
        return budget > 0 && currentExpenses > budget;
    }

    public double getRemainingBudget(double currentExpenses) {
        return getMonthlyBudget() - currentExpenses;
    }

    public double getBudgetPercentage(double currentExpenses) {
        double budget = getMonthlyBudget();
        return budget > 0 ? (currentExpenses / budget) * 100 : 0;
    }
}
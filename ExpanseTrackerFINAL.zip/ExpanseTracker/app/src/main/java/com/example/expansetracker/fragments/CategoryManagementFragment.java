package com.example.expansetracker.fragments;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.expansetracker.R;
import com.example.expansetracker.adapters.CategoryAdapter;
import com.example.expansetracker.database.AppDatabase;
import com.example.expansetracker.database.entity.Category;
import com.example.expansetracker.utils.Constants;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

public class CategoryManagementFragment extends Fragment {
    private FloatingActionButton fabAddCategory;
    private TabLayout tabLayout;
    private RecyclerView rvCategories;
    private CategoryAdapter adapter;
    private List<Category> categoryList = new ArrayList<>();
    private AppDatabase db;
    private long userId;
    private String currentType = Constants.TRANSACTION_TYPE_INCOME;

    @SuppressLint("MissingInflatedId")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category_management, container, false);

        fabAddCategory = view.findViewById(R.id.fab_add_category);
        // Initialize database
        db = AppDatabase.getDatabase(getContext());

        // Get user ID from shared preferences
        userId = getActivity().getSharedPreferences(Constants.PREF_NAME, getActivity().MODE_PRIVATE)
                .getLong(Constants.KEY_USER_ID, 0);

        // Initialize views
        tabLayout = view.findViewById(R.id.tab_layout);
        rvCategories = view.findViewById(R.id.rv_categories);
        fabAddCategory = view.findViewById(R.id.fab_add_category);

        // Setup RecyclerView
        rvCategories.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new CategoryAdapter(getContext(), categoryList);
        rvCategories.setAdapter(adapter);

        // Setup tab selection listener
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    currentType = Constants.TRANSACTION_TYPE_INCOME;
                } else {
                    currentType = Constants.TRANSACTION_TYPE_EXPENSE;
                }
                loadCategories();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        // Setup FAB click listener
        fabAddCategory.setOnClickListener(v -> showAddCategoryDialog());

        // Load initial categories
        loadCategories();

        return view;
    }

    private void loadCategories() {
        // For now just load some dummy data
        // In a real app, this would load from the database
        categoryList.clear();

        // Add dummy categories based on type
        if (currentType.equals(Constants.TRANSACTION_TYPE_INCOME)) {
            categoryList.add(new Category("Salary", Constants.TRANSACTION_TYPE_INCOME, "Salary", "#4CAF50", userId));
            categoryList.add(new Category("Family", Constants.TRANSACTION_TYPE_INCOME, "Family", "#2196F3", userId));
        } else {
            categoryList.add(new Category("Food", Constants.TRANSACTION_TYPE_EXPENSE, "Food", "#F44336", userId));
            categoryList.add(new Category("Transport", Constants.TRANSACTION_TYPE_EXPENSE, "Transport", "#FF9800", userId));
            categoryList.add(new Category("Bank", Constants.TRANSACTION_TYPE_EXPENSE, "Bank", "#9C27B0", userId));
        }

        adapter.notifyDataSetChanged();
    }

    private void showAddCategoryDialog() {
        // Erstelle einen Dialog zum Hinzufügen einer neuen Kategorie
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Add Category");

        // Inflate das Layout für den Dialog
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_category, null);
        builder.setView(view);

        // Initialisiere die Views im Dialog
        final TextInputEditText etCategoryName = view.findViewById(R.id.et_category_name);
        final Spinner spinnerIcon = view.findViewById(R.id.spinner_icon);
        final Button btnColorPicker = view.findViewById(R.id.btn_color_picker);

        // Farbe für die neue Kategorie (Standard)
        final String[] selectedColor = {"#4CAF50"};  // Grün als Standard

        // Icon-Adapter für den Spinner
        List<String> iconList = new ArrayList<>();
        iconList.add("Salary");
        iconList.add("Family");
        iconList.add("Bank");
        iconList.add("Others");

        ArrayAdapter<String> iconAdapter = new ArrayAdapter<>(
                getContext(), android.R.layout.simple_spinner_item, iconList);
        iconAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerIcon.setAdapter(iconAdapter);

        // Farbwähler-Button
        btnColorPicker.setBackgroundColor(Color.parseColor(selectedColor[0]));
        btnColorPicker.setOnClickListener(v -> {
            // Hier könntest du einen ColorPicker Dialog zeigen
            // Für Beispielzwecke wechseln wir einfach zwischen einigen Farben
            String[] colors = {"#4CAF50", "#2196F3", "#F44336", "#FF9800", "#9C27B0"};
            int currentIndex = 0;
            for (int i = 0; i < colors.length; i++) {
                if (colors[i].equals(selectedColor[0])) {
                    currentIndex = i;
                    break;
                }
            }
            int nextIndex = (currentIndex + 1) % colors.length;
            selectedColor[0] = colors[nextIndex];
            btnColorPicker.setBackgroundColor(Color.parseColor(selectedColor[0]));
        });

        // Dialog-Buttons
        builder.setPositiveButton("Add", (dialog, which) -> {
            String categoryName = etCategoryName.getText().toString().trim();
            String iconName = (String) spinnerIcon.getSelectedItem();

            if (!categoryName.isEmpty()) {
                // Kategorie zur Datenbank hinzufügen
                addCategoryToDatabase(categoryName, iconName, selectedColor[0]);
            } else {
                Toast.makeText(getContext(), "Please enter a category name", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        builder.create().show();
    }

    private void addCategoryToDatabase(String name, String icon, String color) {
        // Erstelle eine neue Kategorie
        Category newCategory = new Category(name, currentType, icon, color, userId);

        // In einem echten App würdest du hier die Kategorie zur Datenbank hinzufügen
        // Für dieses Beispiel fügen wir sie einfach zur lokalen Liste hinzu
        categoryList.add(newCategory);
        adapter.notifyDataSetChanged();

        Toast.makeText(getContext(), "Category added: " + name, Toast.LENGTH_SHORT).show();
    }
}
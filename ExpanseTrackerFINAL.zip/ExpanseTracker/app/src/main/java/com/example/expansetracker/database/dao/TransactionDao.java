package com.example.expansetracker.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.expansetracker.database.entity.Transaction;

import java.util.Date;
import java.util.List;

@Dao
public interface TransactionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Transaction transaction);

    @Update
    void update(Transaction transaction);

    @Delete
    void delete(Transaction transaction);

    @Query("SELECT * FROM transactions WHERE user_id = :userId ORDER BY transaction_date DESC")
    LiveData<List<Transaction>> getAllTransactions(long userId);

    @Query("SELECT * FROM transactions WHERE id = :id")
    LiveData<Transaction> getTransactionById(long id);

    @Query("SELECT * FROM transactions WHERE id = :id")
    Transaction getTransactionByIdDirect(long id);

    @Query("SELECT * FROM transactions WHERE user_id = :userId AND transaction_type = :type ORDER BY transaction_date DESC")
    LiveData<List<Transaction>> getTransactionsByType(long userId, String type);

    @Query("SELECT * FROM transactions WHERE user_id = :userId AND transaction_date BETWEEN :startDate AND :endDate ORDER BY transaction_date DESC")
    LiveData<List<Transaction>> getTransactionsByDateRange(long userId, Date startDate, Date endDate);

    @Query("SELECT SUM(amount) FROM transactions WHERE user_id = :userId AND transaction_type = 'INCOME'")
    LiveData<Double> getTotalIncome(long userId);

    @Query("SELECT SUM(amount) FROM transactions WHERE user_id = :userId AND transaction_type = 'EXPENSE'")
    LiveData<Double> getTotalExpense(long userId);

    @Query("SELECT SUM(amount) FROM transactions WHERE user_id = :userId AND transaction_type = 'INCOME' AND transaction_date BETWEEN :startDate AND :endDate")
    LiveData<Double> getTotalIncomeByDateRange(long userId, Date startDate, Date endDate);

    @Query("SELECT SUM(amount) FROM transactions WHERE user_id = :userId AND transaction_type = 'EXPENSE' AND transaction_date BETWEEN :startDate AND :endDate")
    LiveData<Double> getTotalExpenseByDateRange(long userId, Date startDate, Date endDate);

    @Query("SELECT * FROM transactions WHERE user_id = :userId AND category_id = :categoryId ORDER BY transaction_date DESC")
    LiveData<List<Transaction>> getTransactionsByCategory(long userId, long categoryId);

    @Query("DELETE FROM transactions WHERE id = :id")
    void deleteById(long id);

    @Query("SELECT * FROM transactions WHERE user_id = :userId ORDER BY transaction_date DESC LIMIT :i")
    List<Transaction> getRecentTransactions(long userId, int i);
}
package com.example.expansetracker.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.expansetracker.R;
import com.example.expansetracker.fragments.AddTransactionFragment;
import com.example.expansetracker.fragments.ChartFragment;
import com.example.expansetracker.fragments.OverviewFragment;
import com.example.expansetracker.fragments.SettingsFragment;
import com.example.expansetracker.fragments.TransactionsFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    private BottomNavigationView bottomNavigationView;
    private FloatingActionButton fabAddTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        bottomNavigationView = findViewById(R.id.bottom_navigation);
// In der onCreate-Methode der MainActivity
        fabAddTransaction = findViewById(R.id.fab_add_transaction);
        fabAddTransaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFragment(new AddTransactionFragment());
            }
        });
        // Set up navigation
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

        // Hide the middle item (placeholder for FAB)
        bottomNavigationView.getMenu().getItem(2).setEnabled(false);

        // Set default fragment
        if (savedInstanceState == null) {
            loadFragment(new OverviewFragment());
            bottomNavigationView.setSelectedItemId(R.id.navigation_overview);
        }

        // Set up FAB click listener
        fabAddTransaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFragment(new AddTransactionFragment());
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;

        int itemId = item.getItemId();
        if (itemId == R.id.navigation_overview) {
            fragment = new OverviewFragment();
        } else if (itemId == R.id.navigation_chart) {
            fragment = new ChartFragment();
        } else if (itemId == R.id.navigation_transactions) {
            fragment = new TransactionsFragment();
        } else if (itemId == R.id.navigation_settings) {
            fragment = new SettingsFragment();
        }

        return loadFragment(fragment);
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }
}
package com.example.expansetracker.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.expansetracker.R;
import com.example.expansetracker.database.AppDatabase;
import com.example.expansetracker.database.dao.UserDao;
import com.example.expansetracker.database.entity.User;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ForgotPasswordActivity extends AppCompatActivity {

    private TextInputLayout tilEmail;
    private TextInputEditText etEmail;
    private Button btnResetPassword;
    private Button btnBack;

    private AppDatabase db;
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        // Initialize database and executor
        db = AppDatabase.getDatabase(this);
        executorService = Executors.newSingleThreadExecutor();

        // Initialize views
        tilEmail = findViewById(R.id.til_email);
        etEmail = findViewById(R.id.et_email);
        btnResetPassword = findViewById(R.id.btn_reset_password);
        btnBack = findViewById(R.id.btn_back);

        // Setup reset password button
        btnResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateEmail()) {
                    resetPassword();
                }
            }
        });

        // Setup back button
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back to login screen
            }
        });
    }

    private boolean validateEmail() {
        String email = etEmail.getText().toString().trim();
        if (email.isEmpty()) {
            tilEmail.setError("Please enter email");
            return false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tilEmail.setError("Please enter a valid email");
            return false;
        } else {
            tilEmail.setError(null);
            return true;
        }
    }

    private void resetPassword() {
        final String email = etEmail.getText().toString().trim();

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                UserDao userDao = db.userDao();
                final User user = userDao.getUserByEmail(email);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (user != null) {
                            // In a real app, you would send a password reset email here
                            // For this example, we'll just show a message
                            Toast.makeText(ForgotPasswordActivity.this,
                                    "Password reset instructions sent to your email",
                                    Toast.LENGTH_LONG).show();

                            // In a real app, you might generate a temporary password and update the database
                            // Then send an email with instructions to reset the password

                            // For now, just go back to login screen after a short delay
                            new android.os.Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    finish();
                                }
                            }, 2000);
                        } else {
                            tilEmail.setError("Email not found");
                        }
                    }
                });
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executorService != null) {
            executorService.shutdown();
        }
    }
}
package com.example.expansetracker.fragments;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.expansetracker.R;
import com.example.expansetracker.adapters.TransactionAdapter;
import com.example.expansetracker.database.AppDatabase;
import com.example.expansetracker.database.entity.Transaction;
import com.example.expansetracker.models.TransactionModel;
import com.example.expansetracker.utils.BudgetManager;
import com.example.expansetracker.utils.Constants;
import com.google.android.material.tabs.TabLayout;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class OverviewFragment extends Fragment implements TransactionAdapter.TransactionAdapterListener {

    private static final String TAG = "OverviewFragment";

    private TextView tvTotalBalance;
    private TextView tvIncome;
    private TextView tvExpenses;
    private TabLayout tabLayout;
    private RecyclerView rvTransactions;
    private LinearLayout currentWeekContainer;

    private List<TransactionModel> transactionList = new ArrayList<>();
    private List<TransactionModel> currentWeekTransactions = new ArrayList<>();
    private TransactionAdapter transactionAdapter;
    private BudgetManager budgetManager;
    private AppDatabase db;
    private long userId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_overview, container, false);

        // Initialize database
        db = AppDatabase.getDatabase(requireContext());

        // Get user ID
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences(
                Constants.PREF_NAME, requireActivity().MODE_PRIVATE);
        userId = sharedPreferences.getLong(Constants.KEY_USER_ID, 1);

        // Initialize budget manager
        budgetManager = new BudgetManager(requireContext());

        // Initialize views
        tvTotalBalance = view.findViewById(R.id.tv_total_balance);
        tvIncome = view.findViewById(R.id.tv_income);
        tvExpenses = view.findViewById(R.id.tv_expenses);
        tabLayout = view.findViewById(R.id.tab_layout);
        rvTransactions = view.findViewById(R.id.rv_transactions);

        // Finde den Container für Current Week
        currentWeekContainer = view.findViewById(R.id.current_week_container);

        if (currentWeekContainer == null) {
            Log.e(TAG, "Current week container not found in layout!");
        } else {
            Log.d(TAG, "Current week container found successfully");
        }

        // FAB is now managed by MainActivity

        // Check if refresh is requested
        boolean shouldRefresh = false;
        if (getArguments() != null) {
            shouldRefresh = getArguments().getBoolean("REFRESH_DATA", false);
        }

        // Setup RecyclerView
        rvTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));

        // Initialize transaction list
        initializeTransactionList();

        // Setup adapter
        setupTransactionAdapter();

        // Setup tab selection listener
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                filterTransactions(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                filterTransactions(tab.getPosition());
            }
        });

        // Update balances and check budget
        updateBalances();
        checkBudgetStatus();

        // Update current week view
        updateCurrentWeekView();

        // Load real transactions if refresh requested or first load
        if (shouldRefresh) {
            loadTransactions(true);
        }

        return view;
    }

    private void initializeTransactionList() {
        // Initialize with a few transactions if empty
        if (transactionList.isEmpty()) {
            Log.d(TAG, "Initializing transaction list with dummy data");

            // Income transactions
            TransactionModel transaction1 = new TransactionModel();
            transaction1.setId(1);
            transaction1.setAmount(70.0);
            transaction1.setDescription("Investment Income");
            transaction1.setCategoryName("Investment");
            transaction1.setCategoryIcon("ic_investment");
            transaction1.setTransactionDate("24 Mar 25");
            transaction1.setTransactionType("INCOME");

            // Another income transaction
            TransactionModel transaction2 = new TransactionModel();
            transaction2.setId(2);
            transaction2.setAmount(55.0);
            transaction2.setDescription("Family Support");
            transaction2.setCategoryName("Family");
            transaction2.setCategoryIcon("ic_family");
            transaction2.setTransactionDate("23 Mar 25");
            transaction2.setTransactionType("INCOME");

            transactionList.add(transaction1);
            transactionList.add(transaction2);

            // Add transactions to current week list as well
            currentWeekTransactions.add(transaction1);
            currentWeekTransactions.add(transaction2);

            Log.d(TAG, "Added " + transactionList.size() + " transactions to list");
        }
    }

    private void setupTransactionAdapter() {
        // Create adapter and set listener
        transactionAdapter = new TransactionAdapter(requireContext(), transactionList);
        transactionAdapter.setListener(this); // Pass the fragment as the listener
        rvTransactions.setAdapter(transactionAdapter);
        Log.d(TAG, "Transaction adapter setup complete");
    }

    private void loadTransactions(boolean forceRefresh) {
        Log.d(TAG, "Loading transactions from database. Force refresh: " + forceRefresh);

        // In a background thread, load data
        new Thread(() -> {
            // Load transactions from database
            List<Transaction> transactions = db.transactionDao().getRecentTransactions(userId, 10);
            Log.d(TAG, "Loaded " + transactions.size() + " transactions from database");

            // Update UI on main thread
            requireActivity().runOnUiThread(() -> {
                // Clear list and refill
                transactionList.clear();
                currentWeekTransactions.clear();

                // Get current week dates
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
                Date weekStart = cal.getTime();
                cal.add(Calendar.DAY_OF_WEEK, 6);
                Date weekEnd = cal.getTime();

                // Convert transactions to view models
                for (Transaction transaction : transactions) {
                    TransactionModel model = new TransactionModel();
                    model.setId(transaction.getId());
                    model.setAmount(transaction.getAmount());
                    model.setDescription(transaction.getDescription());

                    // Determine category name based on categoryId
                    String categoryName = getCategoryNameFromId(transaction.getCategoryId());
                    model.setCategoryName(categoryName);

                    // Format date
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yy", Locale.getDefault());
                    model.setTransactionDate(dateFormat.format(transaction.getTransactionDate()));

                    model.setTransactionType(transaction.getTransactionType());

                    // Add to main transaction list
                    transactionList.add(model);

                    // Check if transaction is from current week and add to current week list
                    Date transDate = transaction.getTransactionDate();
                    if (transDate != null && !transDate.before(weekStart) && !transDate.after(weekEnd)) {
                        currentWeekTransactions.add(model);
                    }
                }

                // If no database transactions loaded, use initialized list
                if (transactionList.isEmpty() && !forceRefresh) {
                    Log.d(TAG, "No transactions found in database, using dummy data");
                    initializeTransactionList();
                }

                // Update UI
                transactionAdapter.notifyDataSetChanged();
                updateCurrentWeekView();

                // Update totals
                updateBalances();
                checkBudgetStatus();
            });
        }).start();
    }

    private String getCategoryNameFromId(long categoryId) {
        String categoryName;
        switch ((int)categoryId) {
            case 1: categoryName = "Food"; break;
            case 2: categoryName = "Transport"; break;
            case 3: categoryName = "Shopping"; break;
            case 4: categoryName = "Bills"; break;
            case 5: categoryName = "Entertainment"; break;
            case 6: categoryName = "Salary"; break;
            case 7: categoryName = "Family"; break;
            case 8: categoryName = "Investment"; break;
            case 9: categoryName = "Bonus"; break;
            case 10: categoryName = "Health"; break;
            case 11: categoryName = "Bank"; break;
            default: categoryName = "Other";
        }
        Log.d(TAG, "Mapped categoryId " + categoryId + " to name: " + categoryName);
        return categoryName;
    }

    private void updateCurrentWeekView() {
        Log.d(TAG, "Updating current week view with " + currentWeekTransactions.size() + " transactions");

        // Clear existing views in the container
        if (currentWeekContainer != null) {
            currentWeekContainer.removeAllViews();
            Log.d(TAG, "Cleared current week container");
        } else {
            Log.e(TAG, "Current week container is null, cannot update view");
            return; // Container nicht gefunden
        }

        // Add transactions for current week
        for (TransactionModel transaction : currentWeekTransactions) {
            View itemView = getLayoutInflater().inflate(R.layout.item_current_week_transaction, currentWeekContainer, false);
            Log.d(TAG, "Inflated item view for transaction: " + transaction.getDescription());

            // Finde die Views in diesem Element
            ImageView ivCategoryIcon = itemView.findViewById(R.id.iv_category_icon);
            TextView tvTransactionName = itemView.findViewById(R.id.tv_transaction_name);
            TextView tvTransactionDate = itemView.findViewById(R.id.tv_transaction_date);
            TextView tvTransactionAmount = itemView.findViewById(R.id.tv_transaction_amount);
            TextView tvCategoryName = itemView.findViewById(R.id.tv_category_name);
            ImageView ivEdit = itemView.findViewById(R.id.iv_edit);
            ImageView ivDelete = itemView.findViewById(R.id.iv_delete);

            if (ivCategoryIcon == null) {
                Log.e(TAG, "Category icon view not found in layout!");
            }

            // Setze die Daten
            tvTransactionName.setText(transaction.getDescription());
            tvTransactionDate.setText(transaction.getTransactionDate());

            // Format amount and set color
            String formattedAmount;
            if (transaction.getTransactionType().equals("INCOME")) {
                formattedAmount = "+ " + transaction.getAmount();
                tvTransactionAmount.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            } else {
                formattedAmount = "- " + transaction.getAmount();
                tvTransactionAmount.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            }
            tvTransactionAmount.setText(formattedAmount);

            // Setze Kategoriename
            tvCategoryName.setText(transaction.getCategoryName());
            Log.d(TAG, "Setting category name: " + transaction.getCategoryName());

            // Setze das Kategorie-Symbol mit unserer Methode
            if (ivCategoryIcon != null) {
                setCategoryIcon(ivCategoryIcon, transaction.getCategoryName());
            }

            // Setze Klick-Listener für Bearbeiten und Löschen
            final TransactionModel finalTransaction = transaction; // For use in lambda

            if (ivEdit != null) {
                ivEdit.setOnClickListener(v -> onEditTransaction(finalTransaction));
            }

            if (ivDelete != null) {
                ivDelete.setOnClickListener(v -> onDeleteTransaction(finalTransaction));
            }

            // Element zum Container hinzufügen
            currentWeekContainer.addView(itemView);
            Log.d(TAG, "Added transaction item to current week container");
        }
    }

    // This method is called by MainActivity's FAB when in OverviewFragment
    private void navigateToAddTransaction() {
        Fragment fragment = new AddTransactionFragment();
        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    private void filterTransactions(int position) {
        List<TransactionModel> filteredList = new ArrayList<>();

        switch (position) {
            case 0: // All
                filteredList.addAll(transactionList);
                break;
            case 1: // Income
                for (TransactionModel transaction : transactionList) {
                    if (transaction.getTransactionType().equals("INCOME")) {
                        filteredList.add(transaction);
                    }
                }
                break;
            case 2: // Expenses
                for (TransactionModel transaction : transactionList) {
                    if (transaction.getTransactionType().equals("EXPENSE")) {
                        filteredList.add(transaction);
                    }
                }
                break;
        }

        transactionAdapter.updateData(filteredList);
    }

    @Override
    public void onTransactionClick(TransactionModel transaction) {
        // Show transaction details
        Toast.makeText(getContext(), "Transaction clicked: " + transaction.getCategoryName(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onEditClick(TransactionModel transaction) {
        // Navigate to edit transaction
        onEditTransaction(transaction);
    }

    @Override
    public void onDeleteClick(TransactionModel transaction) {
        // Delete transaction
        onDeleteTransaction(transaction);
    }

    @Override
    public void onEditTransaction(TransactionModel transaction) {
        // Navigate to edit transaction with data
        AddTransactionFragment fragment = new AddTransactionFragment();

        // Set up the arguments
        Bundle args = new Bundle();
        args.putLong("transaction_id", transaction.getId());
        args.putDouble("amount", transaction.getAmount());
        args.putString("date", transaction.getTransactionDate());
        args.putString("category", transaction.getCategoryName());
        args.putString("note", transaction.getDescription());
        args.putString("type", transaction.getTransactionType());
        args.putBoolean("edit_mode", true);
        fragment.setArguments(args);

        // Navigate to edit screen
        FragmentTransaction ft = requireActivity().getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.fragment_container, fragment);
        ft.addToBackStack(null);
        ft.commit();
    }

    @Override
    public void onDeleteTransaction(TransactionModel transaction) {
        // Show confirmation dialog
        new AlertDialog.Builder(requireContext())
                .setTitle("Delete Transaction")
                .setMessage("Are you sure you want to delete this transaction?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    // Remove from lists
                    transactionList.remove(transaction);
                    currentWeekTransactions.remove(transaction);

                    // Update adapters and views
                    transactionAdapter.notifyDataSetChanged();
                    updateCurrentWeekView();

                    // Delete from database in background
                    new Thread(() -> {
                        try {
                            // Find transaction in database using the direct method
                            Transaction dbTransaction = db.transactionDao().getTransactionByIdDirect(transaction.getId());

                            // Delete if found
                            if (dbTransaction != null) {
                                db.transactionDao().delete(dbTransaction);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        // Update UI on main thread
                        requireActivity().runOnUiThread(() -> {
                            // Update totals
                            updateBalances();

                            // Notify about deletion
                            onTransactionDeleted();

                            // Show confirmation
                            Toast.makeText(requireContext(),
                                    "Transaction deleted successfully", Toast.LENGTH_SHORT).show();
                        });
                    }).start();
                })
                .setNegativeButton("No", null)
                .show();
    }

    @Override
    public void onTransactionDeleted() {
        // Update balances after transaction deleted
        updateBalances();
        checkBudgetStatus();
    }

    @Override
    public void onTransactionEdited() {
        // Update balances after transaction edited
        updateBalances();
        checkBudgetStatus();

        // Update current week view
        loadTransactions(false);
    }

    private void updateBalances() {
        // Re-calculate balances after transactions are modified
        double income = 0;
        double expense = 0;

        for (TransactionModel transaction : transactionList) {
            if (transaction.getTransactionType().equals("INCOME")) {
                income += transaction.getAmount();
            } else {
                expense += transaction.getAmount();
            }
        }

        double balance = income - expense;

        tvTotalBalance.setText("€" + String.format("%.2f", balance));
        tvIncome.setText(String.format("%.2f", income));
        tvExpenses.setText(String.format("%.2f", expense));
    }

    private void checkBudgetStatus() {
        double currentMonthExpenses = getCurrentMonthExpenses();

        if (budgetManager.isOverBudget(currentMonthExpenses)) {
            showBudgetWarning(currentMonthExpenses, budgetManager.getMonthlyBudget());
        } else if (budgetManager.getBudgetPercentage(currentMonthExpenses) > 80) {
            // Warning when 80% of budget is reached
            showBudgetAlert(currentMonthExpenses, budgetManager.getMonthlyBudget());
        }
    }

    private double getCurrentMonthExpenses() {
        double totalExpenses = 0.0;
        for (TransactionModel transaction : transactionList) {
            if (transaction.getTransactionType().equals("EXPENSE")) {
                totalExpenses += transaction.getAmount();
            }
        }
        return totalExpenses;
    }

    private void showBudgetWarning(double expenses, double budget) {
        // Ensure the container exists
        ViewGroup container = requireView().findViewById(R.id.container_overview);
        if (container == null) return;

        // Remove any existing warnings first
        container.removeAllViews();

        View warningView = getLayoutInflater().inflate(R.layout.budget_warning, null);
        TextView tvMessage = warningView.findViewById(R.id.tv_warning_message);

        tvMessage.setText(String.format("Budget Exceeded! \nExpenses: %.2f \nBudget: %.2f",
                expenses, budget));

        // Add warning to the view
        container.addView(warningView, 0);
    }

    private void showBudgetAlert(double expenses, double budget) {
        // Ensure the container exists
        ViewGroup container = requireView().findViewById(R.id.container_overview);
        if (container == null) return;

        // Remove any existing alerts first
        container.removeAllViews();

        View alertView = getLayoutInflater().inflate(R.layout.budget_alert, null);
        TextView tvMessage = alertView.findViewById(R.id.tv_alert_message);

        tvMessage.setText(String.format("Warning: %.0f%% of your budget is used! \nExpenses: %.2f \nBudget: %.2f",
                (expenses / budget) * 100, expenses, budget));

        // Add alert to the view
        container.addView(alertView, 0);
    }

    // Methode zum Setzen des Kategorie-Symbols
    private void setCategoryIcon(ImageView imageView, String categoryName) {
        if (categoryName == null) categoryName = "Other";

        // Debug log
        Log.d(TAG, "Setting icon for category: " + categoryName);

        int iconResId;
        switch (categoryName.toLowerCase()) {
            case "investment":
                iconResId = R.drawable.ic_investment;
                break;
            case "bonus":
                iconResId = R.drawable.ic_bonus;
                break;
            case "salary":
                iconResId = R.drawable.ic_salary;
                break;
            case "food":
                iconResId = R.drawable.ic_food;
                break;
            case "shopping":
                iconResId = R.drawable.ic_shopping;
                break;
            case "transport":
                iconResId = R.drawable.ic_transport;
                break;
            case "bank":
                iconResId = R.drawable.ic_bank;
                break;
            case "entertainment":
                iconResId = R.drawable.ic_entertainment;
                break;
            case "bills":
                iconResId = R.drawable.ic_bills;
                break;
            case "health":
                iconResId = R.drawable.ic_health;
                break;
            case "family":
                iconResId = R.drawable.ic_family;
                break;
            default:
                iconResId = R.drawable.ic_other;
                break;
        }

        try {
            Log.d(TAG, "Using resource ID: " + iconResId);
            imageView.setImageResource(iconResId);
        } catch (Exception e) {
            Log.e(TAG, "Error setting icon: " + e.getMessage(), e);
            // Fallback zu Standard-Symbol bei Fehler
            try {
                imageView.setImageResource(android.R.drawable.ic_menu_info_details);
            } catch (Exception e2) {
                Log.e(TAG, "Error setting fallback icon: " + e2.getMessage(), e2);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh data when returning to this fragment
        loadTransactions(false);
        checkBudgetStatus();
    }
}
package com.example.expansetracker.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.expansetracker.R;
import com.example.expansetracker.adapters.TransactionAdapter;
import com.example.expansetracker.models.TransactionModel;
import com.example.expansetracker.utils.ExportUtils;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChartFragment extends Fragment implements OnChartValueSelectedListener {

    private TabLayout tabLayoutTimeRange;
    private PieChart pieChart;
    private TextView tvChartAmount;
    private RecyclerView rvChartTransactions;
    private TextView tvSelectedCategory;
    private Button btnExportPDF;
    private Button btnExportCSV;

    private TransactionAdapter transactionAdapter;
    private List<TransactionModel> allTransactions = new ArrayList<>();
    private Map<String, List<TransactionModel>> categoryTransactions = new HashMap<>();
    private List<PieEntry> entries = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chart, container, false);

        // Initialize views
        tabLayoutTimeRange = view.findViewById(R.id.tab_layout_time_range);
        pieChart = view.findViewById(R.id.pie_chart);
        tvChartAmount = view.findViewById(R.id.tv_chart_amount);
        rvChartTransactions = view.findViewById(R.id.rv_chart_transactions);
        tvSelectedCategory = view.findViewById(R.id.tv_selected_category);
        btnExportPDF = view.findViewById(R.id.btn_export_pdf);
        btnExportCSV = view.findViewById(R.id.btn_export_csv);

        // Setup RecyclerView
        rvChartTransactions.setLayoutManager(new LinearLayoutManager(getContext()));
        loadDummyData();
        transactionAdapter = new TransactionAdapter(getContext(), allTransactions);
        rvChartTransactions.setAdapter(transactionAdapter);

        // Setup pie chart
        setupPieChart();
        loadPieChartData();

        // Set chart value selection listener
        pieChart.setOnChartValueSelectedListener(this);

        // Setup tab selection listener
        tabLayoutTimeRange.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                updateChartByTimeRange(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                updateChartByTimeRange(tab.getPosition());
            }
        });

        // Setup export buttons
        btnExportPDF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ExportUtils.verifyStoragePermissions(getActivity())) {
                    ExportUtils.exportToPDF(getContext(), allTransactions, "Transaktionsbericht");
                }
            }
        });

        btnExportCSV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ExportUtils.verifyStoragePermissions(getActivity())) {
                    ExportUtils.exportToCSV(getContext(), allTransactions);
                }
            }
        });

        // Initial state for category display
        tvSelectedCategory.setText("All Transactions");

        return view;
    }

    private void setupPieChart() {
        pieChart.setDrawHoleEnabled(true);
        pieChart.setUsePercentValues(true);
        pieChart.setEntryLabelTextSize(12f);
        pieChart.setEntryLabelColor(Color.BLACK);
        pieChart.setCenterTextSize(24f);
        pieChart.setHoleColor(Color.parseColor("#FFF0F7")); // Match card background
        pieChart.getDescription().setEnabled(false);
        pieChart.setTransparentCircleRadius(61f);
        pieChart.setDrawEntryLabels(false);
        pieChart.setDrawCenterText(false);
        pieChart.getLegend().setEnabled(true);
        pieChart.setHighlightPerTapEnabled(true);  // Enable tapping on segments
    }

    private void loadPieChartData() {
        // Group transactions by category
        categoryTransactions.clear();
        entries.clear();

        float totalAmount = 0f;

        // Group transactions by category
        for (TransactionModel transaction : allTransactions) {
            String category = transaction.getCategoryName();
            float amount = (float) transaction.getAmount();

            // Skip zero or negative amounts
            if (amount <= 0) continue;

            totalAmount += amount;

            // Add transaction to category group
            if (!categoryTransactions.containsKey(category)) {
                categoryTransactions.put(category, new ArrayList<>());
            }
            categoryTransactions.get(category).add(transaction);
        }

        // Create pie entries from category groups
        for (Map.Entry<String, List<TransactionModel>> entry : categoryTransactions.entrySet()) {
            float categoryTotal = 0f;
            for (TransactionModel transaction : entry.getValue()) {
                categoryTotal += transaction.getAmount();
            }

            entries.add(new PieEntry(categoryTotal, entry.getKey()));
        }

        ArrayList<Integer> colors = new ArrayList<>();
        for (int color : ColorTemplate.MATERIAL_COLORS) {
            colors.add(color);
        }
        for (int color : ColorTemplate.VORDIPLOM_COLORS) {
            colors.add(color);
        }

        PieDataSet dataSet = new PieDataSet(entries, "Categories");
        dataSet.setColors(colors);
        dataSet.setValueTextSize(12f);
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setValueFormatter(new PercentFormatter(pieChart));

        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        pieChart.invalidate();

        // Update total amount display
        tvChartAmount.setText("€" + String.format("%.1f", totalAmount));
    }

    private void updateChartByTimeRange(int position) {
        // In a real app, you would filter data based on selected time range
        // For this demo, just update the UI to show different data based on tab
        String timeRange = "";
        switch (position) {
            case 0: // Day
                timeRange = "Day";
                break;
            case 1: // Week
                timeRange = "Week";
                break;
            case 2: // Monthly
                timeRange = "Monthly";
                break;
            case 3: // Yearly
                timeRange = "Yearly";
                break;
        }

        // Reset to show all transactions when time range changes
        transactionAdapter.updateData(allTransactions);
        tvSelectedCategory.setText("All Transactions");

        // In a real app, you would reload the data based on the time range
        // loadDummyData(timeRange);
        // loadPieChartData();
    }

    @Override
    public void onValueSelected(Entry e, Highlight h) {
        // Cast to PieEntry to get the label (category name)
        PieEntry pe = (PieEntry) e;
        String category = pe.getLabel();

        // Show only transactions from this category
        List<TransactionModel> filteredTransactions = categoryTransactions.get(category);

        if (filteredTransactions != null && !filteredTransactions.isEmpty()) {
            transactionAdapter.updateData(filteredTransactions);
            tvSelectedCategory.setText(category + " Transactions");

            // Calculate and show total for this category
            float categoryTotal = 0f;
            for (TransactionModel transaction : filteredTransactions) {
                categoryTotal += transaction.getAmount();
            }
            tvChartAmount.setText("€" + String.format("%.1f", categoryTotal));
        }
    }

    @Override
    public void onNothingSelected() {
        // Reset to show all transactions
        transactionAdapter.updateData(allTransactions);
        tvSelectedCategory.setText("All Transactions");

        // Recalculate total amount
        float totalAmount = 0f;
        for (TransactionModel transaction : allTransactions) {
            totalAmount += transaction.getAmount();
        }
        tvChartAmount.setText("€" + String.format("%.1f", totalAmount));
    }

    private void loadDummyData() {
        // Demo data for example
        allTransactions.clear();

        // Bank transactions
        TransactionModel transaction1 = new TransactionModel();
        transaction1.setId(1);
        transaction1.setAmount(1477.47);
        transaction1.setDescription("Monthly rent");
        transaction1.setCategoryName("Bank");
        transaction1.setCategoryIcon("ic_bank");
        transaction1.setTransactionDate("01 Feb 25");
        transaction1.setTransactionType("EXPENSE");

        // Food transactions
        TransactionModel transaction2 = new TransactionModel();
        transaction2.setId(2);
        transaction2.setAmount(50.23);
        transaction2.setDescription("Grocery shopping");
        transaction2.setCategoryName("Food");
        transaction2.setCategoryIcon("ic_bank");
        transaction2.setTransactionDate("03 Feb 25");
        transaction2.setTransactionType("EXPENSE");

        // Transport transactions
        TransactionModel transaction3 = new TransactionModel();
        transaction3.setId(3);
        transaction3.setAmount(12.34);
        transaction3.setDescription("Taxi fare");
        transaction3.setCategoryName("Transport");
        transaction3.setCategoryIcon("ic_bank");
        transaction3.setTransactionDate("12 JAN 25");
        transaction3.setTransactionType("EXPENSE");

        // Shopping transactions
        TransactionModel transaction4 = new TransactionModel();
        transaction4.setId(4);
        transaction4.setAmount(33.07);
        transaction4.setDescription("New clothes");
        transaction4.setCategoryName("Shopping");
        transaction4.setCategoryIcon("ic_bank");
        transaction4.setTransactionDate("3 JAN 25");
        transaction4.setTransactionType("EXPENSE");

        allTransactions.add(transaction1);
        allTransactions.add(transaction2);
        allTransactions.add(transaction3);
        allTransactions.add(transaction4);
    }
}
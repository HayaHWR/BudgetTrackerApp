package com.example.expansetracker.utils;

import java.text.NumberFormat;
import java.util.Currency;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CurrencyUtils {

    private static final Map<String, String> CURRENCY_SYMBOLS = new HashMap<>();

    static {

        CURRENCY_SYMBOLS.put("USD", "$");
        CURRENCY_SYMBOLS.put("EUR", "€");
        CURRENCY_SYMBOLS.put("GBP", "£");
        CURRENCY_SYMBOLS.put("JPY", "¥");
    }

    public static String formatAmount(double amount, String currencyCode) {
        NumberFormat format = NumberFormat.getCurrencyInstance(Locale.getDefault());
        format.setCurrency(Currency.getInstance(currencyCode));
        return format.format(amount);
    }

    public static String formatAmount(double amount) {
        // Default to INR if no currency provided
        return formatAmount(amount, "EUR");
    }

    public static String getCurrencySymbol(String currencyCode) {
        return CURRENCY_SYMBOLS.getOrDefault(currencyCode, currencyCode);
    }

    public static String formatWithSymbol(double amount, String currencyCode) {
        String symbol = getCurrencySymbol(currencyCode);
        return symbol + " " + String.format("%.2f", amount);
    }

    public static String formatWithSymbol(double amount) {
        // Default to INR if no currency provided
        return formatWithSymbol(amount, "EUR");
    }
}
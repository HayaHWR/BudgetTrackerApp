package com.example.expansetracker.fragments;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.expansetracker.R;
import com.example.expansetracker.database.AppDatabase;
import com.example.expansetracker.database.entity.Category;
import com.example.expansetracker.utils.Constants;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddTransactionFragment extends Fragment {

    private ImageView ivBack;
    private TabLayout tabTransactionType;
    private TextInputLayout tilAmount;
    private TextInputEditText etAmount;
    private TextInputLayout tilDate;
    private TextInputEditText etDate;
    private TextInputLayout tilCategory;
    private AutoCompleteTextView actCategory;
    private TextInputLayout tilNote;
    private TextInputEditText etNote;
    private Button btnSave;

    private String transactionType = "INCOME"; // Default transaction type
    private Date selectedDate = new Date(); // Default to current date
    private AppDatabase database;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_transaction, container, false);

        // Initialize database
        database = AppDatabase.getDatabase(getContext());

        // Initialize all views
        initializeViews(view);

        // Setup back button functionality
        setupBackButton();

        // Setup transaction type tab selection
        setupTransactionTypeTabs();

        // Setup date field with date picker
        setupDateField();

        // Setup category dropdown
        setupCategoryDropdown();

        // Setup save button
        setupSaveButton();

        // Check if editing an existing transaction
        checkForExistingTransaction();

        return view;
    }

    private void initializeViews(View view) {
        ivBack = view.findViewById(R.id.iv_back);
        tabTransactionType = view.findViewById(R.id.tab_transaction_type);
        tilAmount = view.findViewById(R.id.til_amount);
        etAmount = view.findViewById(R.id.et_amount);
        tilDate = view.findViewById(R.id.til_date);
        etDate = view.findViewById(R.id.et_date);
        tilCategory = view.findViewById(R.id.til_category);
        actCategory = view.findViewById(R.id.act_category);
        tilNote = view.findViewById(R.id.til_note);
        etNote = view.findViewById(R.id.et_note);
        btnSave = view.findViewById(R.id.btn_save);
    }

    private void setupBackButton() {
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getActivity() != null) {
                    getActivity().getSupportFragmentManager().popBackStack();
                }
            }
        });
    }

    private void setupTransactionTypeTabs() {
        tabTransactionType.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    transactionType = "INCOME";
                } else {
                    transactionType = "EXPENSE";
                }
                setupCategoryDropdown();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void setupDateField() {
        // Set initial date
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
        etDate.setText(dateFormat.format(selectedDate));

        // Setup date picker dialog
        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                calendar.setTime(selectedDate);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        requireContext(),
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                calendar.set(Calendar.YEAR, year);
                                calendar.set(Calendar.MONTH, month);
                                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                                selectedDate = calendar.getTime();
                                etDate.setText(dateFormat.format(selectedDate));
                            }
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                );
                datePickerDialog.show();
            }
        });
    }

    private void setupCategoryDropdown() {
        String[] categories;

        if (transactionType.equals("INCOME")) {
            categories = new String[]{
                    "Salary",
                    "Investment",
                    "Bonus",
                    "Family",
                    "Freelance",
                    "Rental Income",
                    "Other Income"
            };
        } else {
            categories = new String[]{
                    "Food",
                    "Shopping",
                    "Transport",
                    "Bank",
                    "Entertainment",
                    "Bills",
                    "Health",
                    "Family",
                    "Home Maintenance",
                    "Education",
                    "Personal Care",
                    "Gifts",
                    "Other Expense"
            };
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_dropdown_item_1line,
                categories
        );

        actCategory.setAdapter(adapter);
        actCategory.setText(""); // Reset selection on type change
    }

    private void setupSaveButton() {
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    saveTransaction();
                }
            }
        });
    }

    private void checkForExistingTransaction() {
        Bundle arguments = getArguments();
        if (arguments != null && arguments.containsKey("transaction_id")) {
            long transactionId = arguments.getLong("transaction_id");
            double amount = arguments.getDouble("amount");
            String date = arguments.getString("date");
            String category = arguments.getString("category");
            String note = arguments.getString("note");
            String type = arguments.getString("type");

            // Set UI values for existing transaction
            etAmount.setText(String.valueOf(amount));
            etDate.setText(date);

            // Set correct transaction type tab
            if (type.equals("EXPENSE")) {
                tabTransactionType.getTabAt(1).select();
                transactionType = "EXPENSE";
            } else {
                tabTransactionType.getTabAt(0).select();
                transactionType = "INCOME";
            }

            // Setup and set category
            setupCategoryDropdown();
            actCategory.setText(category);

            // Set note if available
            if (note != null) {
                etNote.setText(note);
            }
        }
    }

    private boolean validateInputs() {
        boolean isValid = true;

        // Validate amount
        String amountString = etAmount.getText().toString().trim();
        if (amountString.isEmpty()) {
            tilAmount.setError("Please enter amount");
            isValid = false;
        } else {
            try {
                double amount = Double.parseDouble(amountString);
                if (amount <= 0) {
                    tilAmount.setError("Amount must be greater than 0");
                    isValid = false;
                } else {
                    tilAmount.setError(null);
                }
            } catch (NumberFormatException exception) {
                tilAmount.setError("Please enter a valid amount");
                isValid = false;
            }
        }

        // Validate category
        String category = actCategory.getText().toString().trim();
        if (category.isEmpty()) {
            tilCategory.setError("Please select a category");
            isValid = false;
        } else {
            tilCategory.setError(null);
        }

        return isValid;
    }

    private void saveTransaction() {
        try {
            // Collect data from input fields
            String amountString = etAmount.getText().toString().trim();
            double amount = Double.parseDouble(amountString);
            String note = etNote.getText().toString().trim();
            String categoryName = actCategory.getText().toString().trim();

            // Get user ID from shared preferences
            long userId = getActivity().getSharedPreferences(Constants.PREF_NAME, getActivity().MODE_PRIVATE)
                    .getLong(Constants.KEY_USER_ID, 1); // Default to 1 if not found

            // Save transaction in a background thread
            AppDatabase.databaseWriteExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        // Create a new category
                        Category newCategory = new Category(
                                categoryName,
                                transactionType,
                                transactionType.equals("INCOME") ? "ic_salary" : "ic_bank",
                                "#4CAF50",
                                userId
                        );
                        long categoryId = database.categoryDao().insert(newCategory);

                        // Create the transaction
                        com.example.expansetracker.database.entity.Transaction transaction =
                                new com.example.expansetracker.database.entity.Transaction(
                                        amount,
                                        categoryName,
                                        categoryId,
                                        selectedDate,
                                        transactionType,
                                        userId,
                                        note
                                );

                        // Save the transaction in the database
                        long transactionId = database.transactionDao().insert(transaction);

                        // Update UI on the main thread
                        if (getActivity() != null) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(), "Transaction saved successfully", Toast.LENGTH_SHORT).show();

                                    // Navigate back to OverviewFragment
                                    Fragment fragment = new OverviewFragment();
                                    getActivity().getSupportFragmentManager()
                                            .beginTransaction()
                                            .replace(R.id.fragment_container, fragment)
                                            .commit();
                                }
                            });
                        }
                    } catch (Exception exception) {
                        if (getActivity() != null) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(), "Error saving: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                }
            });
        } catch (Exception exception) {
            Toast.makeText(getContext(), "Error: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
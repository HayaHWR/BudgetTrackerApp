package com.example.expansetracker.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.expansetracker.R;
import com.example.expansetracker.models.TransactionModel;

import java.util.List;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder> {

    // Interface for transaction interactions
    public interface TransactionAdapterListener {
        void onTransactionClick(TransactionModel transaction);
        void onEditClick(TransactionModel transaction);
        void onDeleteClick(TransactionModel transaction);
        void onEditTransaction(TransactionModel transaction);
        void onDeleteTransaction(TransactionModel transaction);
        void onTransactionDeleted();
        void onTransactionEdited();
    }

    private Context context;
    private List<TransactionModel> transactionList;
    private TransactionAdapterListener listener;

    // Constructor for basic initialization
    public TransactionAdapter(Context context, List<TransactionModel> transactionList) {
        this.context = context;
        this.transactionList = transactionList;
    }

    // Constructor with listener
    public TransactionAdapter(Context context, List<TransactionModel> transactionList, TransactionAdapterListener listener) {
        this.context = context;
        this.transactionList = transactionList;
        this.listener = listener;
    }

    // Method to set the listener separately
    public void setListener(TransactionAdapterListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaction, parent, false);
        return new TransactionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TransactionViewHolder holder, int position) {
        TransactionModel transaction = transactionList.get(position);

        // Set basic data
        holder.tvCategoryName.setText(transaction.getCategoryName());
        holder.tvDate.setText(transaction.getTransactionDate());
        holder.tvDescription.setText(transaction.getDescription());

        // Set category icon based on category name
        setCategoryIcon(holder.ivCategoryIcon, transaction.getCategoryName());

        // Format amount based on transaction type
        String formattedAmount;
        if (transaction.getTransactionType().equals("INCOME")) {
            formattedAmount = "+ " + transaction.getAmount();
            holder.tvAmount.setTextColor(ContextCompat.getColor(context, android.R.color.holo_green_dark));
        } else {
            formattedAmount = "- " + transaction.getAmount();
            holder.tvAmount.setTextColor(ContextCompat.getColor(context, android.R.color.holo_red_dark));
        }
        holder.tvAmount.setText(formattedAmount);

        // Set up click listeners if we have a listener
        if (listener != null) {
            // Item click
            holder.itemView.setOnClickListener(v -> listener.onTransactionClick(transaction));

            // Edit button click
            if (holder.ivEdit != null) {
                holder.ivEdit.setVisibility(View.VISIBLE);
                holder.ivEdit.setOnClickListener(v -> {
                    // Call both methods for compatibility
                    listener.onEditClick(transaction);
                    listener.onEditTransaction(transaction);
                });
            }

            // Delete button click
            if (holder.ivDelete != null) {
                holder.ivDelete.setVisibility(View.VISIBLE);
                holder.ivDelete.setOnClickListener(v -> {
                    // Call both methods for compatibility
                    listener.onDeleteClick(transaction);
                    listener.onDeleteTransaction(transaction);
                });
            }
        } else {
            // Hide action buttons if no listener
            if (holder.ivEdit != null) holder.ivEdit.setVisibility(View.GONE);
            if (holder.ivDelete != null) holder.ivDelete.setVisibility(View.GONE);
        }
    }

    // Helper method to set appropriate icon for each category
    private void setCategoryIcon(ImageView imageView, String categoryName) {
        if (categoryName == null) categoryName = "Other";

        int iconResId;
        switch (categoryName.toLowerCase()) {
            case "investment":
                iconResId = R.drawable.ic_investment;
                break;
            case "bonus":
                iconResId = R.drawable.ic_bonus;
                break;
            case "salary":
                iconResId = R.drawable.ic_salary;
                break;
            case "food":
                iconResId = R.drawable.ic_food;
                break;
            case "shopping":
                iconResId = R.drawable.ic_shopping;
                break;
            case "transport":
                iconResId = R.drawable.ic_transport;
                break;
            case "bank":
                iconResId = R.drawable.ic_bank;
                break;
            case "entertainment":
                iconResId = R.drawable.ic_entertainment;
                break;
            case "bills":
                iconResId = R.drawable.ic_bills;
                break;
            case "health":
                iconResId = R.drawable.ic_health;
                break;
            case "family":
                iconResId = R.drawable.ic_family;
                break;
            default:
                iconResId = R.drawable.ic_other;
        }

        try {
            imageView.setImageResource(iconResId);
        } catch (Exception e) {
            // Fallback to default icon if resource not found
            imageView.setImageResource(android.R.drawable.ic_menu_info_details);
        }
    }

    @Override
    public int getItemCount() {
        return transactionList.size();
    }

    public void updateData(List<TransactionModel> newTransactionList) {
        this.transactionList = newTransactionList;
        notifyDataSetChanged();
    }

    static class TransactionViewHolder extends RecyclerView.ViewHolder {
        ImageView ivCategoryIcon;
        TextView tvCategoryName;
        TextView tvDate;
        TextView tvAmount;
        TextView tvDescription;
        ImageView ivEdit;
        ImageView ivDelete;

        public TransactionViewHolder(@NonNull View itemView) {
            super(itemView);
            // Find all views
            ivCategoryIcon = itemView.findViewById(R.id.iv_category_icon);
            tvCategoryName = itemView.findViewById(R.id.tv_category_name);
            tvDate = itemView.findViewById(R.id.tv_date);
            tvAmount = itemView.findViewById(R.id.tv_amount);
            tvDescription = itemView.findViewById(R.id.tv_description);

            // Find action buttons
            ivEdit = itemView.findViewById(R.id.iv_edit);
            ivDelete = itemView.findViewById(R.id.iv_delete);
        }
    }
}
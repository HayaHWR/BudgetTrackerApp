package com.example.expansetracker.utils;

public class Constants {

    // Shared Preferences
    public static final String PREF_NAME = "expanse_tracker_prefs";
    public static final String KEY_IS_LOGGED_IN = "is_logged_in";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_USER_EMAIL = "user_email";
    public static final String KEY_USER_NAME = "user_name";
    public static final String KEY_CURRENCY_CODE = "currency_code";
    public static final String KEY_LANGUAGE = "language";

    // Transaction Types
    public static final String TRANSACTION_TYPE_INCOME = "INCOME";
    public static final String TRANSACTION_TYPE_EXPENSE = "EXPENSE";

    // Time Ranges
    public static final String TIME_RANGE_DAY = "day";
    public static final String TIME_RANGE_WEEK = "week";
    public static final String TIME_RANGE_MONTH = "month";
    public static final String TIME_RANGE_YEAR = "year";

    // Bundle Keys
    public static final String BUNDLE_TRANSACTION_ID = "transaction_id";
    public static final String BUNDLE_CATEGORY_ID = "category_id";

    // Request Codes
    public static final int REQUEST_CODE_ADD_TRANSACTION = 1001;
    public static final int REQUEST_CODE_EDIT_TRANSACTION = 1002;
    public static final int REQUEST_CODE_ADD_CATEGORY = 1003;
    public static final int REQUEST_CODE_EDIT_CATEGORY = 1004;

    // Default Values
    public static final String DEFAULT_CURRENCY_CODE = "EUR";
    public static final String DEFAULT_LANGUAGE = "en";
}
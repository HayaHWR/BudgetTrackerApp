package com.example.expansetracker.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.example.expansetracker.database.entity.Transaction;
import com.example.expansetracker.models.TransactionModel;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ExportHelper {

    private static final String TAG = "ExportHelper";

    // Export als CSV
    public static boolean exportToCSV(Context context, List<TransactionModel> transactions) {
        try {
            // Erstelle den Dateinamen mit Zeitstempel
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            String fileName = "Transactions_" + timeStamp + ".csv";

            // Erstelle CSV-Datei im Download-Ordner
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File file = new File(downloadsDir, fileName);

            // Prüfe, ob der Ordner existiert
            if (!downloadsDir.exists()) {
                downloadsDir.mkdirs();
            }

            FileWriter writer = new FileWriter(file);

            // Schreibe CSV-Header
            writer.append("Date,Category,Description,Amount,Type,Note\n");

            // Schreibe Transaktionsdaten
            for (TransactionModel transaction : transactions) {
                writer.append(transaction.getTransactionDate()).append(",");
                writer.append(transaction.getCategoryName()).append(",");
                writer.append(transaction.getDescription() != null ? transaction.getDescription() : "").append(",");
                writer.append(String.valueOf(transaction.getAmount())).append(",");
                writer.append(transaction.getTransactionType()).append(",");
                writer.append(transaction.getNote() != null ? transaction.getNote() : "").append("\n");
            }

            writer.flush();
            writer.close();

            // Benachrichtige den Benutzer
            Toast.makeText(context, "CSV-Datei gespeichert in: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();

            // Öffne die Datei mit einer anderen App
            openFile(context, file);

            return true;
        } catch (IOException e) {
            Log.e(TAG, "CSV-Export fehlgeschlagen", e);
            Toast.makeText(context, "Export fehlgeschlagen: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    // Export als PDF
    public static boolean exportToPDF(Context context, List<TransactionModel> transactions) {
        Document document = new Document(PageSize.A4);
        try {
            // Erstelle den Dateinamen mit Zeitstempel
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            String fileName = "Transactions_" + timeStamp + ".pdf";

            // Erstelle PDF-Datei im Download-Ordner
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File file = new File(downloadsDir, fileName);

            // Prüfe, ob der Ordner existiert
            if (!downloadsDir.exists()) {
                downloadsDir.mkdirs();
            }

            PdfWriter.getInstance(document, new FileOutputStream(file));
            document.open();

            // Füge Titel hinzu
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
            Paragraph title = new Paragraph("Transaction Report", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            // Füge Datum hinzu
            Font dateFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL);
            Paragraph date = new Paragraph("Generated on: " +
                    new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(new Date()), dateFont);
            date.setAlignment(Element.ALIGN_CENTER);
            document.add(date);

            // Leerzeile
            document.add(new Paragraph(" "));

            // Erstelle Tabelle
            PdfPTable table = new PdfPTable(5); // 5 Spalten
            table.setWidthPercentage(100);

            // Definiere relative Spaltenbreiten
            float[] columnWidths = {2f, 1.5f, 1f, 1f, 2f};
            table.setWidths(columnWidths);

            // Tabellen-Header
            Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
            addTableHeader(table, headerFont);

            // Tabellen-Inhalt
            Font cellFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);
            for (TransactionModel transaction : transactions) {
                addTableRow(table, transaction, cellFont);
            }

            document.add(table);
            document.close();

            // Benachrichtige den Benutzer
            Toast.makeText(context, "PDF-Datei gespeichert in: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();

            // Öffne die Datei mit einer anderen App
            openFile(context, file);

            return true;
        } catch (Exception e) {
            Log.e(TAG, "PDF-Export fehlgeschlagen", e);
            if (document.isOpen()) {
                document.close();
            }
            Toast.makeText(context, "Export fehlgeschlagen: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private static void addTableHeader(PdfPTable table, Font font) {
        String[] headers = {"Date", "Category", "Amount", "Type", "Note"};
        for (String header : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(header, font));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPadding(5);
            table.addCell(cell);
        }
    }

    private static void addTableRow(PdfPTable table, TransactionModel transaction, Font font) {
        table.addCell(new Phrase(transaction.getTransactionDate(), font));
        table.addCell(new Phrase(transaction.getCategoryName(), font));
        table.addCell(new Phrase(String.valueOf(transaction.getAmount()), font));
        table.addCell(new Phrase(transaction.getTransactionType(), font));
        table.addCell(new Phrase(transaction.getNote() != null ? transaction.getNote() : "", font));
    }

    // Hilfsmethode zum Öffnen einer Datei mit anderer App
    private static void openFile(Context context, File file) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        Uri uri = FileProvider.getUriForFile(context,
                context.getApplicationContext().getPackageName() + ".provider", file);

        if (file.getName().endsWith(".pdf")) {
            intent.setDataAndType(uri, "application/pdf");
        } else if (file.getName().endsWith(".csv")) {
            intent.setDataAndType(uri, "text/csv");
        }

        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        if (intent.resolveActivity(context.getPackageManager()) != null) {
            context.startActivity(intent);
        } else {
            Toast.makeText(context, "Keine App zum Öffnen dieser Datei gefunden", Toast.LENGTH_SHORT).show();
        }
    }
}